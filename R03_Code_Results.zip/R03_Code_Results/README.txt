Team Details

* Shreyas Chikkballapur Muralidhara - schikkb  
* Sharath Narayana - snaraya9

We will share a drive which contains the data needed to run the programs

The codebase has three files
  - generate_csv.py
  - Page_Ranking.ipynb
  - Response Recommender.ipynb

generate_csv.py
* Generate_csv program scrapes through the dataset and creates a csv of feature set
* This program can be run using python generate_csv.py
* this create a file called data_generated.csv
* This is used to create dataframes in the other programs,

Page_Ranking.ipynb
* This program has the implementation for the page ranking algorithm
* This program can be run on google colab
* The ranking of the program and graphs of the nodes generated would be the output of this

Response Recommender.ipynb
* This program has the implementation for the Response Recommendation
* This program can be run on google colab
* The accuracy and F1 score of each model is displayed here
